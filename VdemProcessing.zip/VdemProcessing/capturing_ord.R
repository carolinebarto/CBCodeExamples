inUse <- c("v2elage", "v2elcomvot", "v2elfemrst", "v2elgvsuflvl", "v2elsuffrage", "v2elwestmon", "v2eldonate_ord",
                 "v2elpubfin_ord", "v2elembaut_ord", "v2elembaut_ord", "v2elmulpar_ord", "v2elrgstry_ord", "v2elvotbuy_ord",
                 "v2elirreg_ord", "v2elintim_ord", "v2elpeace_ord", "v2elfrcamp_ord", "v2elpdcamp_ord", "v2elpaidig_ord",
                 "v2elfrfair_ord", "v2eldommon", "v2elintmon", "v2elmonden", "v2elmonref", "v2elrstrct", "v2elaccept_ord",
                 "v2elasmoff_ord", "v2elprescons", "v2elprescumul", "v2elrsthog", "v2ellocons", "v2ellocumul", "v2elparlel",
                 "v2elthresh", "v2elreggov", "v2elsrgel", "v2elrgpwr_ord", "v2ellocgov", "v2ellocelc", "v2ellocpwr_ord", 
                 "v2elffelr_ord", "v2elffelrbin_ord", "v2elsnlsff_ord", "v2elsnlfc_0","v2elsnlfc_1","v2elsnlfc_2","v2elsnlfc_3","v2elsnlfc_4","v2elsnlfc_5","v2elsnlfc_6",
                 "v2elsnlfc_7","v2elsnlfc_8","v2elsnlfc_9","v2elsnlfc_10","v2elsnlfc_11","v2elsnlfc_12","v2elsnlfc_13",
                 "v2elsnlfc_14","v2elsnlfc_15","v2elsnlfc_16","v2elsnlfc_17","v2elsnlfc_18","v2elsnlfc_19","v2elsnlfc_20","v2elsnlfc_21",
                 "v2elsnmrfc_0","v2elsnmrfc_1","v2elsnmrfc_2","v2elsnmrfc_3","v2elsnmrfc_4","v2elsnmrfc_5","v2elsnmrfc_6",
                 "v2elsnmrfc_7","v2elsnmrfc_8","v2elsnmrfc_9","v2elsnmrfc_10","v2elsnmrfc_11","v2elsnmrfc_12","v2elsnmrfc_13",
                 "v2elsnmrfc_14","v2elsnmrfc_15","v2elsnmrfc_16","v2elsnmrfc_17","v2elsnmrfc_18","v2elsnmrfc_19","v2elsnmrfc_20","v2elsnmrfc_21",
                 "country_id","year", "v2exapupap", "v2exapup", "v2exdfvthg_ord", "v2exremhog_ord", "v2exdfdshg_ord", "v2exdfpphg_ord", 
                 "v2ex_elechog", "v2exfxtmhg", "v2ex_hogw", "v2ex_hosconhog", "v2expathhg", "v2exdjcbhg_ord", "v2exdjdshg_ord",
                 "v2exrmhgnp_0","v2exrmhgnp_1","v2exrmhgnp_2","v2exrmhgnp_3","v2exrmhgnp_4","v2exrmhgnp_5","v2exrmhgnp_6","v2exrmhgnp_7","v2exrmhgnp_8",
                 "v2exctlhg_0","v2exctlhg_1","v2exctlhg_2","v2exctlhg_3","v2exctlhg_4","v2exctlhg_5","v2exctlhg_6","v2exctlhg_7","v2exctlhg_8",
                 "v2lgdomchm_ord", "v2lgqstexp_ord", "v2lginvstp_ord", "v2lgfunds_ord", "v2lgdsadlo_ord", "v2lgcomslo_ord",
                 "v2lgsrvlo_ord", "v2lgello", "v2lginello", "v2lgqugen", "v2lglegpup_ord", "v2lgelecup", "v2lginelup", "v2lgintbup",
                 "v2exaphogp", "v2lglegplo_ord", "v2lgoppart_ord", "v2elrgpwr_ord")
eltype <- rep(NA, 10)
for ( i in 1:10)
{
  eltype[i] <- paste("v2eltype_", i-1, sep = "")
}
totalNeeded <- c(inUse, eltype, "v2x_regime", "v2exhoshog", "v2lgbicam")

all <- read.csv("SPEC HW/Research project/V-Dem-CY-Full+Others-v11.1.csv")

vdemOriginal <- all[, totalNeeded]
vdemOriginal <- vdemOriginal[vdemOriginal$year >= 1945,]
write.csv(vdemOriginal,"Unaltered_vdem.csv")

